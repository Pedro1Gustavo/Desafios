document.addEventListener('DOMContentLoaded', function () {
    
    const tabs = document.querySelectorAll('.tab-button');
    const contents = document.querySelectorAll('.tab-content');

    tabs.forEach(tab => {
        tab.addEventListener('click', function () {
            tabs.forEach(t => t.classList.remove('active'));
            contents.forEach(c => c.classList.remove('active'));

            this.classList.add('active');
            document.getElementById(this.getAttribute('data-tab')).classList.add('active');
        });
    });

    
    const themeToggle = document.getElementById('theme-toggle');
    const body = document.body;

    themeToggle.addEventListener('click', function () {
        body.classList.toggle('dark-theme');
    });

    
    const btnSemanal = document.getElementById('btn-semanal');
    const btnMensal = document.getElementById('btn-mensal');
    const calendarioSemanal = document.getElementById('calendario-semanal');
    const calendarioMensal = document.getElementById('calendario-mensal');

    btnSemanal.addEventListener('click', function () {
        btnSemanal.classList.add('active');
        btnMensal.classList.remove('active');
        calendarioSemanal.classList.remove('hidden');
        calendarioMensal.classList.add('hidden');
    });

    btnMensal.addEventListener('click', function () {
        btnSemanal.classList.remove('active');
        btnMensal.classList.add('active');
        calendarioSemanal.classList.add('hidden');
        calendarioMensal.classList.remove('hidden');
    });

    
    const modalEditar = document.getElementById('modal-editar');
    const closeModal = document.querySelector('.modal .close');

    closeModal.addEventListener('click', function () {
        modalEditar.classList.add('hidden');
    });

    window.addEventListener('click', function (e) {
        if (e.target == modalEditar) {
            modalEditar.classList.add('hidden');
        }
    });

    
    loadTurmas();

    
    const formCadastro = document.getElementById('form-cadastro');
    formCadastro.addEventListener('submit', function (e) {
        e.preventDefault();
        const turma = {
            id: Date.now(),  // unique ID for each turma
            nome: document.getElementById('nome').value,
            tipo: document.getElementById('tipo').value,
            dataInicio: document.getElementById('dataInicio').value,
            diaSemana: document.getElementById('diaSemana').value,
            horarioInicio: document.getElementById('horarioInicio').value,
            horarioFim: document.getElementById('horarioFim').value
        };
        saveTurma(turma);
        formCadastro.reset();
    });

    
    const formRelatorio = document.getElementById('form-relatorio');
    formRelatorio.addEventListener('submit', function (e) {
        e.preventDefault();
        generateReport();
        formRelatorio.reset();
    });

    
    function loadTurmas() {
        const turmas = getTurmasFromLocalStorage();
        const listaTurmas = document.getElementById('lista-turmas');
        listaTurmas.innerHTML = '';
        turmas.forEach(turma => {
            const turmaElement = createTurmaElement(turma);
            listaTurmas.appendChild(turmaElement);
        });
    }


    function saveTurma(turma) {
        const turmas = getTurmasFromLocalStorage();
        turmas.push(turma);
        localStorage.setItem('turmas', JSON.stringify(turmas));
        loadTurmas(); 
    }

    
    function getTurmasFromLocalStorage() {
        const turmas = localStorage.getItem('turmas');
        return turmas ? JSON.parse(turmas) : [];
    }

    
    function createTurmaElement(turma) {
        const div = document.createElement('div');
        div.className = 'turma-item';
        div.innerHTML = `
            <h3>${turma.nome}</h3>
            <p>Tipo: ${turma.tipo}</p>
            <p>Data de Início: ${turma.dataInicio}</p>
            <p>Dia da Semana: ${turma.diaSemana}</p>
            <p>Horário: ${turma.horarioInicio} - ${turma.horarioFim}</p>
            <button class="btn-editar">Editar</button>
            <button class="btn-excluir">Excluir</button>
        `;
        div.querySelector('.btn-editar').addEventListener('click', () => editTurma(turma.id));
        div.querySelector('.btn-excluir').addEventListener('click', () => deleteTurma(turma.id));
        return div;
    }


    function deleteTurma(id) {
        let turmas = getTurmasFromLocalStorage();
        turmas = turmas.filter(turma => turma.id !== id);
        localStorage.setItem('turmas', JSON.stringify(turmas));
        loadTurmas(); 
    }

    
    function editTurma(id) {
        
        const turmas = getTurmasFromLocalStorage();
        const turma = turmas.find(turma => turma.id === id);
        if (turma) {
            modalEditar.classList.remove('hidden');
            document.getElementById('editar-id').value = turma.id;
            document.getElementById('editar-nome').value = turma.nome;
            document.getElementById('editar-tipo').value = turma.tipo;
            document.getElementById('editar-dataInicio').value = turma.dataInicio;
            document.getElementById('editar-diaSemana').value = turma.diaSemana;
            document.getElementById('editar-horarioInicio').value = turma.horarioInicio;
            document.getElementById('editar-horarioFim').value = turma.horarioFim;
        }
    }

    
    const formEditar = document.getElementById('form-editar');
    formEditar.addEventListener('submit', function (e) {
        e.preventDefault();
        const turmaId = parseInt(document.getElementById('editar-id').value, 10);
        const updatedTurma = {
            id: turmaId,
            nome: document.getElementById('editar-nome').value,
            tipo: document.getElementById('editar-tipo').value,
            dataInicio: document.getElementById('editar-dataInicio').value,
            diaSemana: document.getElementById('editar-diaSemana').value,
            horarioInicio: document.getElementById('editar-horarioInicio').value,
            horarioFim: document.getElementById('editar-horarioFim').value
        };
        let turmas = getTurmasFromLocalStorage();
        turmas = turmas.map(turma => turma.id === turmaId ? updatedTurma : turma);
        localStorage.setItem('turmas', JSON.stringify(turmas));
        loadTurmas(); 
        modalEditar.classList.add('hidden');
    });

    
    function generateReport() {
        const turmas = getTurmasFromLocalStorage();
        const numeroTurmas = turmas.length;
        const totalHoras = turmas.reduce((total, turma) => {
            const start = new Date(`1970-01-01T${turma.horarioInicio}:00`);
            const end = new Date(`1970-01-01T${turma.horarioFim}:00`);
            const diff = (end - start) / (1000 * 60 * 60); 
            return total + diff;
        }, 0);
        const valorHoraCurso = parseFloat(document.getElementById('valorHoraCurso').value);
        const valorHoraSuperModulo = parseFloat(document.getElementById('valorHoraSuperModulo').value);
        const valorHoraSuperReforco = parseFloat(document.getElementById('valorHoraSuperReforco').value);
        const valorTotal = turmas.reduce((total, turma) => {
            let valorHora;
            switch (turma.tipo) {
                case 'Curso':
                    valorHora = valorHoraCurso;
                    break;
                case 'Super Módulo':
                    valorHora = valorHoraSuperModulo;
                    break;
                case 'Super Reforço':
                    valorHora = valorHoraSuperReforco;
                    break;
            }
            const start = new Date(`1970-01-01T${turma.horarioInicio}:00`);
            const end = new Date(`1970-01-01T${turma.horarioFim}:00`);
            const diff = (end - start) / (1000 * 60 * 60); 
            return total + (valorHora * diff);
        }, 0);

        const resultado = document.getElementById('resultado-relatorio');
        resultado.innerHTML = `
            <p>Número de turmas: ${numeroTurmas}</p>
            <p>Total de horas: ${totalHoras.toFixed(2)}</p>
            <p>Valor total: R$ ${valorTotal.toFixed(2)}</p>
        `;
    }

    async function syncWithBackend() {
        try {
            const turmas = getTurmasFromLocalStorage();
            // Send turmas to backend
            const response = await fetch('/api/saveTurmas', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(turmas)
            });
            const data = await response.json();
            console.log('Sync successful:', data);
        } catch (error) {
            console.error('Sync failed:', error);
        }
    }

    
    async function loadFromBackend() {
        try {
            const response = await fetch('/api/getTurmas');
            const turmas = await response.json();
            localStorage.setItem('turmas', JSON.stringify(turmas));
            loadTurmas(); // Refresh the display
        } catch (error) {
            console.error('Failed to load from backend:', error);
        }
    }
});
